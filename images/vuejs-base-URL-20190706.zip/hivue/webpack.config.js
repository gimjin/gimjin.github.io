const path = require('path')
const history = require('connect-history-api-fallback')
const VueLoaderPlugin = require('vue-loader/lib/plugin')
const HtmlWebpackPlugin = require('html-webpack-plugin')
const webpack = require('webpack')

const BASE_ROUTER = '/app-one/' // <= setting base URL

module.exports = {
  entry: {
    main: './src/main.js'
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    publicPath: BASE_ROUTER
  },
  devServer: {
    host: 'localhost',
    port: 3000,
    open: true,
    publicPath: BASE_ROUTER,
    before (app) {
      // Only vue-router history mode setting
      app.use(history({
        index: BASE_ROUTER + 'index.html'
      }))
    }
  },
  module: {
    rules: [
      {
        test: /\.vue$/,
        loader: 'vue-loader'
      },
      {
        test: /\.png$/,
        loader: 'file-loader'
      }
    ]
  },
  plugins: [
    new webpack.DefinePlugin({
      BASE_ROUTER: JSON.stringify(BASE_ROUTER)
    }),
    new VueLoaderPlugin(),
    new HtmlWebpackPlugin({
      template: 'index.html'
    })
  ]
}
