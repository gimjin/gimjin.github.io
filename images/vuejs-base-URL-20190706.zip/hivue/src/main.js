import Vue from 'vue/dist/vue.esm.js'
import router from './router/index.js'
import App from './App.vue'

new Vue({
  render: function (h) {
    return h(App)
  },
  router
}).$mount('#app')
