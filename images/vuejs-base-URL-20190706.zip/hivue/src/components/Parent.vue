<template>
  <div>
    <router-link to="child">
      Go to child.
    </router-link>
    <router-view />
  </div>
</template>
