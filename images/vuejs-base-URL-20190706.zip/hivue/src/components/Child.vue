<template>
  <div>
    <router-link to="/">
      Go to parent.
    </router-link>
    <img :src="require('../assets/icon.png')" style="display: block;">
  </div>
</template>
