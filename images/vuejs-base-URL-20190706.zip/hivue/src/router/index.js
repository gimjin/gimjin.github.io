import Vue from 'vue/dist/vue.esm.js'
import VueRouter from 'vue-router'
import Parent from '../components/Parent.vue'
import Child from '../components/Child.vue'

Vue.use(VueRouter)

export default new VueRouter({
  mode: 'history',
  base: BASE_ROUTER, // from webpack.config.js
  routes: [{
    path: '/',
    component: Parent,
    children: [{
      path: 'child',
      component: Child
    }]
  }]
})
